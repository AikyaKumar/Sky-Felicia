The Tools > Mission Architect > Create Demo Scene command generates
MissionArchitectDemo.unity in this directory.

It does not overwrite existing scenes.
