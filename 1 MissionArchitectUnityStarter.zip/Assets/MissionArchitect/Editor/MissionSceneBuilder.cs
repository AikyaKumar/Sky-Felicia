using UnityEditor;
using UnityEditor.SceneManagement;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UIElements;

namespace MissionArchitect.EditorTools
{
    /// <summary>
    /// Creates a demonstration scene without overwriting the user's current scene.
    /// Run from Tools > Mission Architect > Create Demo Scene.
    /// </summary>
    public static class MissionSceneBuilder
    {
        private const string Base = "Assets/MissionArchitect";
        private const string ScenePath = Base + "/Scenes/MissionArchitectDemo.unity";
        private const string PanelPath = Base + "/Resources/MissionPanel.asset";

        [MenuItem("Tools/Mission Architect/Create Demo Scene")]
        public static void CreateDemoScene()
        {
            if (AssetDatabase.LoadAssetAtPath<SceneAsset>(ScenePath) != null)
            {
                EditorUtility.DisplayDialog("Scene already exists",
                    "MissionArchitectDemo.unity is already present. Open that scene from the Project window. Your existing scene was not overwritten.", "OK");
                return;
            }

            VisualTreeAsset layout = AssetDatabase.LoadAssetAtPath<VisualTreeAsset>(Base + "/Resources/MissionUI.uxml");
            if (layout == null)
            {
                EditorUtility.DisplayDialog("Missing UI", "Import the entire Assets/MissionArchitect folder first.", "OK");
                return;
            }

            PanelSettings panel = AssetDatabase.LoadAssetAtPath<PanelSettings>(PanelPath);
            if (panel == null)
            {
                panel = ScriptableObject.CreateInstance<PanelSettings>();
                AssetDatabase.CreateAsset(panel, PanelPath);
            }

            // Additive creation avoids discarding or replacing the current open scene.
            Scene scene = EditorSceneManager.NewScene(NewSceneSetup.EmptyScene, NewSceneMode.Additive);
            GameObject host = new GameObject("Mission Architect UI + Game Controller");
            SceneManager.MoveGameObjectToScene(host, scene);
            UIDocument doc = host.AddComponent<UIDocument>();
            doc.panelSettings = panel;
            doc.visualTreeAsset = layout;
            host.AddComponent<MissionGameController>();

            GameObject cameraObject = new GameObject("Background Camera");
            SceneManager.MoveGameObjectToScene(cameraObject, scene);
            Camera camera = cameraObject.AddComponent<Camera>();
            camera.clearFlags = CameraClearFlags.SolidColor;
            camera.backgroundColor = new Color(.025f, .05f, .11f, 1f);
            cameraObject.tag = "MainCamera";

            EditorSceneManager.SaveScene(scene, ScenePath);
            EditorSceneManager.CloseScene(scene, true);
            AssetDatabase.SaveAssets();
            EditorUtility.DisplayDialog("Mission Architect ready",
                "Demo scene created at Assets/MissionArchitect/Scenes/MissionArchitectDemo.unity. Open it and press Play. Your existing open scene was preserved.", "OK");
        }
    }
}
