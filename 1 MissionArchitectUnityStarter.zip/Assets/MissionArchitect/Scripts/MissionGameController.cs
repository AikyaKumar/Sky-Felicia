using System;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UIElements;

namespace MissionArchitect
{
    [RequireComponent(typeof(UIDocument))]
    public sealed class MissionGameController : MonoBehaviour
    {
        private static readonly string[] StageTitles =
        {
            "Mission Brief", "Orbit Planning", "Scientific Payload", "Spacecraft Systems",
            "Launch Vehicle", "Preflight Review", "Mission Operations", "Mission Report"
        };

        private MissionConfiguration config = new MissionConfiguration();
        private MissionSession session;
        private MissionResult result;
        private readonly List<string> missionLog = new List<string>();
        private int stage;
        private int highestUnlockedStage;
        private VisualElement root;
        private VisualElement stageContent;
        private VisualElement telemetry;
        private ScrollView stageScroll;
        private Button[] stageButtons;
        private Label stageName;
        private Label missionName;
        private Label missionSubtitle;
        private Label modelMode;

        private void OnEnable()
        {
            UIDocument document = GetComponent<UIDocument>();
            root = document.rootVisualElement;
            if (root == null) return;

            StyleSheet stylesheet = Resources.Load<StyleSheet>("MissionStyle");
            if (stylesheet != null) root.styleSheets.Add(stylesheet);

            stageContent = root.Q<VisualElement>("stage-content");
            telemetry = root.Q<VisualElement>("telemetry-values");
            stageScroll = root.Q<ScrollView>("stage-scroll");
            stageName = root.Q<Label>("stage-name");
            missionName = root.Q<Label>("mission-name");
            missionSubtitle = root.Q<Label>("mission-subtitle");
            modelMode = root.Q<Label>("model-mode");

            stageButtons = new Button[StageTitles.Length];
            for (int i = 0; i < stageButtons.Length; i++)
            {
                int requestedStage = i;
                stageButtons[i] = root.Q<Button>("nav-" + i);
                stageButtons[i].clicked += () => GoTo(requestedStage);
            }
            root.Q<Button>("restart").clicked += Restart;
            Render();
        }

        private void Restart()
        {
            config = new MissionConfiguration();
            session = null;
            result = null;
            missionLog.Clear();
            stage = 0;
            highestUnlockedStage = 0;
            Render(true);
        }

        private void GoTo(int requested)
        {
            if (session != null)
            {
                if ((requested == 6 && result == null) || (requested == 7 && result != null))
                    stage = requested;
            }
            else if (requested >= 0 && requested <= highestUnlockedStage && requested <= 5)
                stage = requested;
            Render(true);
        }

        private void ContinueTo(int requested)
        {
            if (session != null || requested < 0 || requested > 5) return;
            stage = requested;
            highestUnlockedStage = Math.Max(highestUnlockedStage, requested);
            Render(true);
        }

        private void Render(bool resetScroll = false)
        {
            if (stageContent == null || telemetry == null) return;
            stageContent.Clear();
            stageName.text = StageTitles[stage];
            for (int i = 0; i < stageButtons.Length; i++)
            {
                Button b = stageButtons[i];
                bool accessible = session == null ? i <= highestUnlockedStage && i <= 5
                    : i == 6 && result == null || i == 7 && result != null;
                b.SetEnabled(accessible);
                if (i == stage) b.AddToClassList("active");
                else b.RemoveFromClassList("active");
            }

            switch (stage)
            {
                case 0: DrawBrief(); break;
                case 1: DrawOrbit(); break;
                case 2: DrawPayload(); break;
                case 3: DrawEngineering(); break;
                case 4: DrawLaunch(); break;
                case 5: DrawReview(); break;
                case 6: DrawOperations(); break;
                case 7: DrawResult(); break;
            }
            DrawTelemetry();
            if (resetScroll && stageScroll != null) stageScroll.scrollOffset = Vector2.zero;
        }

        private void Header(string title, string description)
        {
            AddLabel(stageContent, "STAGE " + (stage + 1).ToString("00") + " / " +
                (session == null ? "MISSION DESIGN" : "LIVE MISSION"), "eyebrow");
            AddLabel(stageContent, title, "screen-title");
            AddLabel(stageContent, description, "screen-description");
        }

        private static Label AddLabel(VisualElement parent, string text, string className)
        {
            Label label = new Label(text);
            label.AddToClassList(className);
            parent.Add(label);
            return label;
        }

        private void AddInformation(string heading, string details)
        {
            VisualElement box = new VisualElement();
            box.AddToClassList("insight");
            AddLabel(box, heading, "insight-title");
            AddLabel(box, details, "insight-body");
            stageContent.Add(box);
        }

        private Button AddButton(VisualElement parent, string text, string css, Action action, bool enabled = true)
        {
            Button button = new Button(action) { text = text };
            button.AddToClassList(css);
            button.SetEnabled(enabled);
            parent.Add(button);
            return button;
        }

        private void BottomButtons(int previous, int next, string label)
        {
            VisualElement row = new VisualElement();
            row.AddToClassList("actions");
            AddButton(row, "<  BACK", "secondary-button", () => ContinueTo(previous), previous >= 0);
            AddButton(row, label + "  >", "primary-button", () => ContinueTo(next));
            stageContent.Add(row);
        }

        private void OptionGroup(string heading, MissionOption[] options, string chosen,
            Func<MissionOption, string> extra, Action<string> onChoose)
        {
            AddLabel(stageContent, heading, "section-label");
            VisualElement grid = new VisualElement();
            grid.AddToClassList("card-grid");
            foreach (MissionOption option in options)
            {
                MissionOption selectedOption = option;
                Button card = new Button(() => { onChoose(selectedOption.Id); Render(); });
                card.AddToClassList("choice-card");
                if (option.Id == chosen) card.AddToClassList("selected");
                AddLabel(card, (option.Id == chosen ? "[ SELECTED ]  " : "") + option.Name, "choice-name");
                AddLabel(card, option.Description, "choice-description");
                string stats = extra(option);
                if (!string.IsNullOrEmpty(stats)) AddLabel(card, stats, "choice-meta");
                grid.Add(card);
            }
            stageContent.Add(grid);
        }

        private void DrawBrief()
        {
            Header("Your mission starts here.", "Become the mission director. Choose a real-world goal and design a satellite capable of returning useful scientific data.");
            OptionGroup("01 / CHOOSE SCIENCE MISSION", MissionCatalog.Missions, config.mission,
                option => option.Capacity + " science points required  /  $120M available", id => config.mission = id);
            MissionOption selected = MissionCatalog.Find(MissionCatalog.Missions, config.mission);
            AddInformation("MISSION SUCCESS CRITERION", "Return at least " + selected.Capacity +
                " science points to Earth. Scientific observations only count after successful downlink.");
            BottomButtons(-1, 1, "PLAN ORBIT");
        }

        private void DrawOrbit()
        {
            Header("Choose your orbit.", "The orbit affects observation opportunities, science quality, and the mass your launcher can deliver.");
            OptionGroup("02 / ORBITAL CONFIGURATION", MissionCatalog.Orbits, config.orbit,
                option => "$" + option.Cost + "M  /  " + Mathf.RoundToInt(option.Relevance(config.mission) * 100) + "% mission fit",
                id => config.orbit = id);
            AddInformation("ORBITAL TRADE-OFF", "These orbit presets are simplified educational scenarios. Actual orbit design requires altitude, inclination, launch-site and ground-track analysis.");
            BottomButtons(0, 2, "SELECT PAYLOAD");
        }

        private void DrawPayload()
        {
            Header("Design the scientific payload.", "More advanced instruments can produce better science, but they also demand more mass, energy and data transmission.");
            OptionGroup("03 / PRIMARY INSTRUMENT", MissionCatalog.Payloads, config.payload,
                option => "$" + option.Cost + "M  /  " + option.Mass + "kg  /  " + option.Watts + "W  /  " + option.Data + "GB",
                id => config.payload = id);
            MissionOption p = MissionCatalog.Find(MissionCatalog.Payloads, config.payload);
            MissionOption orbit = MissionCatalog.Find(MissionCatalog.Orbits, config.orbit);
            AddInformation("EXPECTED SCIENTIFIC CAPABILITY", "This payload-orbit combination could collect approximately " +
                Mathf.RoundToInt(p.Relevance(config.mission) * orbit.Relevance(config.mission)) +
                " points per ideal full observation, before energy, storage and downlink limitations.");
            BottomButtons(1, 3, "ENGINEER SPACECRAFT");
        }

        private void DrawEngineering()
        {
            Header("Build your spacecraft.", "Each component solves one problem while creating costs elsewhere. Balance power, communications, storage and mass.");
            OptionGroup("04A / POWER GENERATION", MissionCatalog.Solar, config.solar,
                x => "$" + x.Cost + "M  /  " + x.Mass + "kg  /  " + x.Watts + "W nominal", id => config.solar = id);
            OptionGroup("04B / COMMUNICATIONS", MissionCatalog.Antennas, config.antenna,
                x => "$" + x.Cost + "M  /  " + x.Data + "GB per contact", id => config.antenna = id);
            OptionGroup("04C / ENERGY RESERVE", MissionCatalog.Batteries, config.battery,
                x => "$" + x.Cost + "M  /  " + x.Capacity + "Wh stored energy", id => config.battery = id);
            OptionGroup("04D / DATA STORAGE", MissionCatalog.Storages, config.storage,
                x => "$" + x.Cost + "M  /  " + x.Capacity + "GB onboard", id => config.storage = id);
            BottomButtons(2, 4, "PLAN LAUNCH");
        }

        private void DrawLaunch()
        {
            Header("Choose your launch vehicle.", "The rocket must lift your spacecraft to the selected orbit. Larger launchers cost more, but unnecessary capacity provides no scientific benefit.");
            MissionOption orbit = MissionCatalog.Find(MissionCatalog.Orbits, config.orbit);
            OptionGroup("05 / ROCKET SELECTION", MissionCatalog.Rockets, config.rocket,
                x => "$" + x.Cost + "M  /  " + Mathf.FloorToInt(x.Capacity * orbit.Capacity / 100f) + "kg to orbit",
                id => config.rocket = id);
            DesignReview review = MissionEngine.Review(config);
            AddInformation("CURRENT SPACECRAFT", review.SpacecraftMassKg + "kg of spacecraft mass. Your launcher supports " +
                review.LaunchCapacityKg + "kg to this orbit. Total current mission cost: $" + review.CostMillions + "M.");
            BottomButtons(3, 5, "RUN PREFLIGHT REVIEW");
        }

        private void ReviewLine(string name, string details, string status)
        {
            VisualElement row = new VisualElement();
            row.AddToClassList("review-item");
            if (status == "BLOCKED") row.AddToClassList("blocked");
            if (status == "CAUTION") row.AddToClassList("warning");
            AddLabel(row, status + "   " + name, "review-heading");
            AddLabel(row, details, "review-details");
            stageContent.Add(row);
        }

        private void DrawReview()
        {
            Header("Preflight systems review.", "Before launching, make sure the design satisfies hard budget and mass requirements. Other constraints may limit performance but do not necessarily prevent launch.");
            DesignReview r = MissionEngine.Review(config);
            AddLabel(stageContent, "06 / READINESS CHECKS", "section-label");
            ReviewLine("Budget", "$" + r.CostMillions + "M / $120M", r.CostMillions > 120 ? "BLOCKED" : "PASS");
            ReviewLine("Rocket capability", r.SpacecraftMassKg + "kg spacecraft / " + r.LaunchCapacityKg + "kg supported", r.SpacecraftMassKg > r.LaunchCapacityKg ? "BLOCKED" : "PASS");
            ReviewLine("Peak power", r.PeakPowerW + "W required / " + r.SolarPowerW + "W nominal solar", r.PeakPowerW > r.SolarPowerW ? "CAUTION" : "PASS");
            ReviewLine("Data return", r.DataPerObservationGb + "GB produced / " + r.DataPerContactGb + "GB per contact", r.DataPerObservationGb > r.DataPerContactGb ? "CAUTION" : "PASS");
            ReviewLine("Data storage", r.StorageGb + "GB available", r.StorageGb < r.DataPerObservationGb ? "CAUTION" : "PASS");

            if (!r.IsLaunchReady) AddInformation("LAUNCH BLOCKED", string.Join(" ", r.Blockers));
            else if (r.Warnings.Count > 0) AddInformation("FLIGHT CLEARANCE WITH WARNINGS", string.Join(" ", r.Warnings));
            else AddInformation("FLIGHT CLEARANCE", "Your design meets the mandatory launch checks. Operational decisions will still determine the mission outcome.");

            VisualElement actions = new VisualElement(); actions.AddToClassList("actions");
            AddButton(actions, "<  REVISE DESIGN", "secondary-button", () => ContinueTo(3));
            AddButton(actions, "AUTHORIZE LAUNCH  >", "primary-button", Launch, r.IsLaunchReady);
            stageContent.Add(actions);
        }

        private void Launch()
        {
            if (!MissionEngine.Review(config).IsLaunchReady) return;
            session = new MissionSession(config);
            result = null;
            missionLog.Clear();
            stage = 6;
            highestUnlockedStage = 6;
            Render(true);
        }

        private void Statistic(VisualElement parent, string name, string value)
        {
            VisualElement box = new VisualElement(); box.AddToClassList("stat-box");
            AddLabel(box, name, "stat-name"); AddLabel(box, value, "stat-number");
            parent.Add(box);
        }

        private void DrawOperations()
        {
            Header("Mission operations are live.", "Hardware is now locked. Manage four orbital windows: collect science, transmit observations or conserve limited battery energy.");
            VisualElement stats = new VisualElement(); stats.AddToClassList("stat-grid");
            Statistic(stats, "BATTERY", session.BatteryWh + " / " + session.BatteryCapacityWh + " Wh");
            Statistic(stats, "ONBOARD DATA", Mathf.RoundToInt(session.StorageUsedGb) + " / " + session.StorageCapacityGb + " GB");
            Statistic(stats, "SCIENCE RETURNED", Mathf.RoundToInt(session.ScienceReturned) + " / " + session.TargetScience);
            stageContent.Add(stats);

            OrbitalWindow w = MissionEngine.Windows[session.Turn];
            VisualElement eventBox = new VisualElement(); eventBox.AddToClassList("event-panel");
            AddLabel(eventBox, "ORBITAL WINDOW " + (session.Turn + 1) + " OF " + MissionEngine.Windows.Length, "eyebrow");
            AddLabel(eventBox, w.Name, "event-title");
            AddLabel(eventBox, w.Description + " " + (w.GroundContact ? "Ground contact AVAILABLE." : "No ground contact this pass."), "event-caption");
            stageContent.Add(eventBox);

            AddLabel(stageContent, "CHOOSE ONE OPERATION", "section-label");
            VisualElement options = new VisualElement(); options.AddToClassList("card-grid");
            OperationCard(options, "FULL OBSERVATION", "Maximize onboard science, at higher battery and storage cost.", MissionAction.FullObservation, true);
            OperationCard(options, "EFFICIENT OBSERVATION", "Reduced energy and data demand, but less science.", MissionAction.EfficientObservation, true);
            OperationCard(options, "DOWNLINK DATA", "Return collected information to Earth.", MissionAction.Downlink, w.GroundContact);
            OperationCard(options, "CONSERVE ENERGY", "Keep science instruments idle and recharge when possible.", MissionAction.ConserveEnergy, true);
            stageContent.Add(options);

            if (missionLog.Count > 0)
            {
                AddLabel(stageContent, "MISSION EVENT LOG", "section-label");
                for (int i = missionLog.Count - 1; i >= 0; i--)
                    AddLabel(stageContent, "PASS " + (i + 1) + "  /  " + missionLog[i], "log-entry");
            }
            AddInformation("REMEMBER", "Data generated aboard the satellite is not the same as scientific information returned to Earth. Your ground-contact decisions matter.");
        }

        private void OperationCard(VisualElement parent, string name, string desc, MissionAction action, bool enabled)
        {
            Button card = new Button(() => TakeAction(action));
            card.AddToClassList("choice-card");
            AddLabel(card, name, "choice-name");
            AddLabel(card, desc, "choice-description");
            if (!enabled) AddLabel(card, "NOT AVAILABLE IN THIS WINDOW", "choice-meta");
            card.SetEnabled(enabled);
            parent.Add(card);
        }

        private void TakeAction(MissionAction action)
        {
            string explanation = session.Execute(action);
            missionLog.Add(explanation);
            if (session.Complete)
            {
                result = session.Evaluate();
                stage = 7;
                highestUnlockedStage = 7;
            }
            Render(true);
        }

        private void DrawResult()
        {
            Header("Mission complete.", "Your final score depends on returned science, operational reliability and resource efficiency. Learn from the results and try again.");
            VisualElement panel = new VisualElement(); panel.AddToClassList("result-panel");
            AddLabel(panel, result.Outcome, "eyebrow");
            AddLabel(panel, result.Score + " / 100", "result-score");
            AddLabel(panel, result.CompletionPercent + "% of the science objective achieved", "result-caption");
            stageContent.Add(panel);

            AddLabel(stageContent, "08 / POST-MISSION REPORT", "section-label");
            VisualElement stats = new VisualElement(); stats.AddToClassList("stat-grid");
            Statistic(stats, "SCIENCE COLLECTED", result.ScienceCollected + " pts");
            Statistic(stats, "SCIENCE RETURNED", result.ScienceReturned + " pts");
            Statistic(stats, "DATA TRANSMITTED", result.DataReturnedGb + " GB");
            Statistic(stats, "DATA LOST", result.DataLostGb + " GB");
            Statistic(stats, "BATTERY INTERRUPTIONS", result.Brownouts.ToString());
            Statistic(stats, "TOTAL COST", "$" + result.CostMillions + "M");
            stageContent.Add(stats);

            AddInformation("MISSION ANALYST RECOMMENDATIONS", string.Join(" ", result.Suggestions));
            VisualElement buttons = new VisualElement(); buttons.AddToClassList("actions");
            AddButton(buttons, "<  REDESIGN", "secondary-button", Redesign);
            AddButton(buttons, "RE-FLY THIS SPACECRAFT  >", "primary-button", Replay);
            stageContent.Add(buttons);
        }

        private void Redesign()
        {
            session = null; result = null; missionLog.Clear();
            stage = 3; highestUnlockedStage = 5;
            Render(true);
        }

        private void Replay()
        {
            session = new MissionSession(config);
            result = null; missionLog.Clear();
            stage = 6; highestUnlockedStage = 6;
            Render(true);
        }

        private void DrawTelemetry()
        {
            telemetry.Clear();
            DesignReview r = MissionEngine.Review(config);
            MissionOption mission = MissionCatalog.Find(MissionCatalog.Missions, config.mission);
            missionName.text = mission.Name;
            missionSubtitle.text = mission.Description;
            modelMode.text = session != null ? "IN ORBIT" : "DESIGN MODE";
            if (session == null)
            {
                Meter("MISSION BUDGET", r.CostMillions, 120, "$" + r.CostMillions + "M / $120M", r.CostMillions > 120);
                Meter("LAUNCH MASS", r.SpacecraftMassKg, r.LaunchCapacityKg, r.SpacecraftMassKg + " / " + r.LaunchCapacityKg + " kg", r.SpacecraftMassKg > r.LaunchCapacityKg);
                Meter("PEAK POWER", r.PeakPowerW, r.SolarPowerW, r.PeakPowerW + " / " + r.SolarPowerW + " W", r.PeakPowerW > r.SolarPowerW);
                Meter("DATA PER CONTACT", r.DataPerObservationGb, r.DataPerContactGb, r.DataPerObservationGb + " / " + r.DataPerContactGb + " GB", r.DataPerObservationGb > r.DataPerContactGb);
            }
            else
            {
                Meter("BATTERY", session.BatteryWh, session.BatteryCapacityWh, session.BatteryWh + " / " + session.BatteryCapacityWh + " Wh", session.BatteryWh < session.BatteryCapacityWh * .2f);
                Meter("ONBOARD DATA", session.StorageUsedGb, session.StorageCapacityGb, Mathf.RoundToInt(session.StorageUsedGb) + " / " + session.StorageCapacityGb + " GB", session.StorageUsedGb > session.StorageCapacityGb * .85f);
                Meter("RETURNED SCIENCE", session.ScienceReturned, session.TargetScience, Mathf.RoundToInt(session.ScienceReturned) + " / " + session.TargetScience + " pts", false);
            }
        }

        private void Meter(string name, float value, float maximum, string display, bool warning)
        {
            VisualElement line = new VisualElement(); line.AddToClassList("telemetry-line");
            AddLabel(line, name, "telemetry-key");
            AddLabel(line, display, "telemetry-value");
            telemetry.Add(line);

            VisualElement track = new VisualElement(); track.AddToClassList("meter-track");
            VisualElement fill = new VisualElement(); fill.AddToClassList("meter-fill");
            if (warning) fill.AddToClassList("warn");
            else if (session != null) fill.AddToClassList("good");
            float percent = Mathf.Clamp01(value / Math.Max(1f, maximum)) * 100f;
            fill.style.width = Length.Percent(percent);
            track.Add(fill);
            telemetry.Add(track);
        }
    }
}
