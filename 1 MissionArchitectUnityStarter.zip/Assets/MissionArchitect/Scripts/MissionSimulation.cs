using System;
using System.Collections.Generic;

namespace MissionArchitect
{
    // Pure C# model: it can be tested independently of Unity graphics and UI.
    // All numbers are illustrative gameplay values, not certified mission data.
    [Serializable]
    public sealed class MissionConfiguration
    {
        public string mission = "wildfire";
        public string orbit = "sun";
        public string payload = "thermal";
        public string solar = "expanded";
        public string antenna = "standard";
        public string battery = "standard";
        public string storage = "standard";
        public string rocket = "medium";

        public MissionConfiguration Copy()
        {
            return (MissionConfiguration)MemberwiseClone();
        }
    }

    public sealed class MissionOption
    {
        public readonly string Id;
        public readonly string Name;
        public readonly string Description;
        public readonly int Cost;
        public readonly int Mass;
        public readonly int Watts;
        public readonly int Data;
        public readonly int Capacity;
        public readonly float Wildfire;
        public readonly float Forests;
        public readonly float Crops;

        public MissionOption(string id, string name, string description,
            int cost = 0, int mass = 0, int watts = 0, int data = 0,
            int capacity = 0, float wildfire = 0, float forests = 0, float crops = 0)
        {
            Id = id; Name = name; Description = description;
            Cost = cost; Mass = mass; Watts = watts; Data = data;
            Capacity = capacity; Wildfire = wildfire; Forests = forests; Crops = crops;
        }

        public float Relevance(string mission)
        {
            switch (mission)
            {
                case "wildfire": return Wildfire;
                case "forests": return Forests;
                case "crops": return Crops;
                default: throw new ArgumentException("Unknown mission: " + mission);
            }
        }
    }

    public static class MissionCatalog
    {
        public const int BudgetMillions = 120;

        public static readonly MissionOption[] Missions =
        {
            new MissionOption("wildfire", "Wildfire Watch", "Detect fire hotspots and return timely observations.", capacity:110),
            new MissionOption("forests", "Forest Sentinel", "Observe long-term changes in forest coverage.", capacity:108),
            new MissionOption("crops", "Crop Pulse", "Monitor vegetation and agricultural conditions.", capacity:108)
        };

        public static readonly MissionOption[] Orbits =
        {
            new MissionOption("sun", "Sun-Synchronous", "Consistent observation times and lighting.", cost:6, capacity:92, wildfire:1.0f, forests:1.17f, crops:1.16f),
            new MissionOption("rapid", "Regional Low Orbit", "Prioritizes repeated looks at selected regions.", cost:3, capacity:100, wildfire:1.18f, forests:.90f, crops:.89f),
            new MissionOption("wide", "Wide-Coverage Orbit", "Favors broader footprints over fine detail.", cost:5, capacity:89, wildfire:1.04f, forests:.97f, crops:.94f)
        };

        public static readonly MissionOption[] Payloads =
        {
            new MissionOption("basic", "Standard Optical Camera", "Simple visible-light imagery; modest requirements.", cost:9, mass:45, watts:60, data:38, wildfire:30, forests:43, crops:36),
            new MissionOption("hires", "High-Resolution Camera", "Sharper imaging, higher mass and data demand.", cost:25, mass:95, watts:125, data:100, wildfire:35, forests:57, crops:45),
            new MissionOption("thermal", "Thermal Imaging Sensor", "Detects thermal patterns and hotspots.", cost:24, mass:75, watts:140, data:72, wildfire:72, forests:25, crops:31),
            new MissionOption("multi", "Multispectral Imager", "Multiple bands for vegetation and land analysis.", cost:23, mass:85, watts:105, data:85, wildfire:40, forests:69, crops:70)
        };

        public static readonly MissionOption[] Solar =
        {
            new MissionOption("compact", "Compact Solar Array", "Light and inexpensive; limited generation.", cost:8, mass:25, watts:220),
            new MissionOption("expanded", "Expanded Solar Array", "More power but greater mass and cost.", cost:18, mass:55, watts:350)
        };

        public static readonly MissionOption[] Antennas =
        {
            new MissionOption("standard", "Standard Radio", "Cheap and light; lower downlink capacity.", cost:6, mass:18, watts:26, data:45),
            new MissionOption("high", "High-Gain Antenna", "More data per contact; heavier and power hungry.", cost:16, mass:38, watts:60, data:115)
        };

        public static readonly MissionOption[] Batteries =
        {
            new MissionOption("standard", "Standard Battery", "Enough stored energy for basic operations.", cost:5, mass:23, capacity:230),
            new MissionOption("robust", "Extended Battery", "Additional reserve for demanding eclipse passes.", cost:11, mass:45, capacity:440)
        };

        public static readonly MissionOption[] Storages =
        {
            new MissionOption("standard", "Standard Data Storage", "Affordable, but fills up quickly.", cost:4, mass:12, capacity:125),
            new MissionOption("expanded", "Expanded Data Storage", "More room for observations before downlink.", cost:10, mass:25, capacity:250)
        };

        public static readonly MissionOption[] Rockets =
        {
            new MissionOption("light", "Aquila Light", "Affordable rocket for small spacecraft.", cost:14, capacity:260),
            new MissionOption("medium", "Aquila Medium", "Balanced launch performance and price.", cost:27, capacity:420),
            new MissionOption("heavy", "Aquila Heavy", "Large capacity at much greater cost.", cost:46, capacity:650)
        };

        public static MissionOption Find(MissionOption[] options, string id)
        {
            for (int i = 0; i < options.Length; i++)
                if (options[i].Id == id) return options[i];
            throw new ArgumentException("Unknown option: " + id);
        }
    }

    public sealed class DesignReview
    {
        public int CostMillions;
        public int SpacecraftMassKg;
        public int LaunchCapacityKg;
        public int PeakPowerW;
        public int SolarPowerW;
        public int DataPerObservationGb;
        public int DataPerContactGb;
        public int StorageGb;
        public readonly List<string> Blockers = new List<string>();
        public readonly List<string> Warnings = new List<string>();
        public bool IsLaunchReady { get { return Blockers.Count == 0; } }
    }

    public enum MissionAction
    {
        FullObservation,
        EfficientObservation,
        Downlink,
        ConserveEnergy
    }

    public sealed class OrbitalWindow
    {
        public readonly string Name;
        public readonly string Description;
        public readonly float Sunlight;
        public readonly bool GroundContact;
        public readonly float Quality;

        public OrbitalWindow(string name, string description, float sunlight, bool groundContact, float quality)
        {
            Name = name; Description = description;
            Sunlight = sunlight; GroundContact = groundContact; Quality = quality;
        }
    }

    public static class MissionEngine
    {
        public static readonly OrbitalWindow[] Windows =
        {
            new OrbitalWindow("First observation pass", "Clear sunlight, but no ground contact.", .95f, false, 1f),
            new OrbitalWindow("Ground station pass", "Good chance to send data to Earth.", .8f, true, .85f),
            new OrbitalWindow("Earth eclipse", "Almost no solar generation. Optical science is limited.", .04f, false, .94f),
            new OrbitalWindow("Final ground contact", "Final opportunity to return science data.", .95f, true, 1f)
        };

        public static DesignReview Review(MissionConfiguration c)
        {
            MissionOption orbit = MissionCatalog.Find(MissionCatalog.Orbits, c.orbit);
            MissionOption instrument = MissionCatalog.Find(MissionCatalog.Payloads, c.payload);
            MissionOption solar = MissionCatalog.Find(MissionCatalog.Solar, c.solar);
            MissionOption antenna = MissionCatalog.Find(MissionCatalog.Antennas, c.antenna);
            MissionOption battery = MissionCatalog.Find(MissionCatalog.Batteries, c.battery);
            MissionOption storage = MissionCatalog.Find(MissionCatalog.Storages, c.storage);
            MissionOption rocket = MissionCatalog.Find(MissionCatalog.Rockets, c.rocket);

            DesignReview r = new DesignReview();
            r.CostMillions = 18 + orbit.Cost + instrument.Cost + solar.Cost + antenna.Cost
                + battery.Cost + storage.Cost + rocket.Cost;
            r.SpacecraftMassKg = 110 + instrument.Mass + solar.Mass + antenna.Mass + battery.Mass + storage.Mass;
            r.LaunchCapacityKg = (int)Math.Floor(rocket.Capacity * orbit.Capacity / 100f);
            r.PeakPowerW = 48 + instrument.Watts + antenna.Watts;
            r.SolarPowerW = solar.Watts;
            r.DataPerObservationGb = instrument.Data;
            r.DataPerContactGb = antenna.Data;
            r.StorageGb = storage.Capacity;

            if (r.CostMillions > MissionCatalog.BudgetMillions)
                r.Blockers.Add("Budget exceeded by $" + (r.CostMillions - MissionCatalog.BudgetMillions) + "M.");
            if (r.SpacecraftMassKg > r.LaunchCapacityKg)
                r.Blockers.Add("Rocket capacity exceeded by " + (r.SpacecraftMassKg - r.LaunchCapacityKg) + " kg.");
            if (r.PeakPowerW > r.SolarPowerW)
                r.Warnings.Add("Peak simultaneous power demand exceeds nominal solar generation.");
            if (r.DataPerObservationGb > r.DataPerContactGb)
                r.Warnings.Add("One observation generates more data than a single contact can return.");
            if (r.DataPerObservationGb > r.StorageGb)
                r.Warnings.Add("One full observation may exceed onboard storage.");
            return r;
        }
    }

    internal sealed class SciencePacket
    {
        public float Data;
        public float Value;
        public SciencePacket(float data, float value) { Data = data; Value = value; }
    }

    public sealed class MissionResult
    {
        public string Outcome;
        public int Score;
        public int CompletionPercent;
        public int ScienceCollected;
        public int ScienceReturned;
        public int DataReturnedGb;
        public int DataLostGb;
        public int RemainingDataGb;
        public int Brownouts;
        public int CostMillions;
        public readonly List<string> Suggestions = new List<string>();
    }

    public sealed class MissionSession
    {
        public readonly MissionConfiguration Configuration;
        public readonly DesignReview Design;
        private readonly List<SciencePacket> packets = new List<SciencePacket>();
        private readonly MissionOption instrument, orbit, solar, antenna, battery, storage;
        private float collected, returned, downloaded, lost, storageUsed;
        private int failures;

        public int Turn { get; private set; }
        public int BatteryWh { get; private set; }
        public float StorageUsedGb { get { return storageUsed; } }
        public float ScienceReturned { get { return returned; } }
        public float ScienceCollected { get { return collected; } }
        public int BatteryCapacityWh { get { return battery.Capacity; } }
        public int StorageCapacityGb { get { return storage.Capacity; } }
        public int TargetScience { get { return MissionCatalog.Find(MissionCatalog.Missions, Configuration.mission).Capacity; } }
        public bool Complete { get { return Turn == MissionEngine.Windows.Length; } }

        public MissionSession(MissionConfiguration configuration)
        {
            Configuration = configuration.Copy();
            Design = MissionEngine.Review(Configuration);
            if (!Design.IsLaunchReady) throw new InvalidOperationException("Critical design constraints are not satisfied.");
            instrument = MissionCatalog.Find(MissionCatalog.Payloads, Configuration.payload);
            orbit = MissionCatalog.Find(MissionCatalog.Orbits, Configuration.orbit);
            solar = MissionCatalog.Find(MissionCatalog.Solar, Configuration.solar);
            antenna = MissionCatalog.Find(MissionCatalog.Antennas, Configuration.antenna);
            battery = MissionCatalog.Find(MissionCatalog.Batteries, Configuration.battery);
            storage = MissionCatalog.Find(MissionCatalog.Storages, Configuration.storage);
            BatteryWh = (int)(battery.Capacity * .72f);
        }

        public string Execute(MissionAction action)
        {
            if (Complete) throw new InvalidOperationException("Mission already complete.");
            OrbitalWindow w = MissionEngine.Windows[Turn];
            if (action == MissionAction.Downlink && !w.GroundContact)
                throw new InvalidOperationException("No ground station is available during this window.");

            float solarGain = solar.Watts * w.Sunlight * .60f;
            float energyCost = 48f;
            string message;

            if (action == MissionAction.FullObservation || action == MissionAction.EfficientObservation)
            {
                bool efficient = action == MissionAction.EfficientObservation;
                energyCost += instrument.Watts * .92f * (efficient ? .58f : 1f);
                if (BatteryWh + solarGain < energyCost)
                {
                    failures++;
                    message = "Insufficient battery: observation aborted. Change power capacity or operating strategy.";
                }
                else
                {
                    bool isOptical = Configuration.payload != "thermal";
                    float night = w.Sunlight < .2f && isOptical ? .22f : 1f;
                    float science = instrument.Relevance(Configuration.mission)
                        * orbit.Relevance(Configuration.mission) * w.Quality * night * (efficient ? .61f : 1f);
                    float producedGb = instrument.Data * (efficient ? .62f : 1f);
                    float storedGb = Math.Max(0f, Math.Min(producedGb, storage.Capacity - storageUsed));
                    float value = science * storedGb / producedGb;
                    if (storedGb > 0f) packets.Add(new SciencePacket(storedGb, value));
                    storageUsed += storedGb;
                    collected += value;
                    lost += producedGb - storedGb;
                    message = "Collected " + Math.Round(storedGb) + " GB and " + Math.Round(value)
                        + " onboard science points." + (storedGb < producedGb ? " Storage overflow lost data." : "")
                        + (night < 1f ? " Darkness reduced optical imaging value." : "");
                }
            }
            else if (action == MissionAction.Downlink)
            {
                energyCost += antenna.Watts * .82f;
                if (BatteryWh + solarGain < energyCost)
                {
                    failures++;
                    message = "Insufficient battery: communication session interrupted.";
                }
                else
                {
                    float allowance = antenna.Data, sentGb = 0f, sentScience = 0f;
                    while (allowance > .00001f && packets.Count > 0)
                    {
                        SciencePacket p = packets[0];
                        float amount = Math.Min(p.Data, allowance);
                        float value = p.Value * amount / p.Data;
                        p.Data -= amount;
                        p.Value -= value;
                        allowance -= amount;
                        sentGb += amount;
                        sentScience += value;
                        if (p.Data < .00001f) packets.RemoveAt(0);
                    }
                    storageUsed = Math.Max(0f, storageUsed - sentGb);
                    downloaded += sentGb;
                    returned += sentScience;
                    message = "Returned " + Math.Round(sentGb) + " GB and "
                        + Math.Round(sentScience) + " science points to Earth.";
                }
            }
            else
            {
                message = w.Sunlight < .2f ? "Systems conserved energy during eclipse." : "Battery recharged while instruments remained idle.";
            }

            BatteryWh = (int)Math.Max(0, Math.Min(battery.Capacity, Math.Floor(BatteryWh + solarGain - energyCost)));
            Turn++;
            return message;
        }

        public MissionResult Evaluate()
        {
            if (!Complete) throw new InvalidOperationException("Complete all four operating windows first.");
            float completion = Math.Min(100f, returned / TargetScience * 100f);
            float operationQuality = Math.Max(0f, 100f - failures * 35f - (lost > 0f ? 12f : 0f));
            float costQuality = Math.Max(0f, 100f - Design.CostMillions / 120f * 40f);

            MissionResult result = new MissionResult
            {
                CompletionPercent = (int)Math.Round(completion),
                Score = (int)Math.Round(completion * .70f + operationQuality * .17f + costQuality * .13f),
                Outcome = completion >= 100f ? "MISSION SUCCESS" : completion >= 50f ? "PARTIAL SUCCESS" : "MISSION INCOMPLETE",
                ScienceCollected = (int)Math.Round(collected),
                ScienceReturned = (int)Math.Round(returned),
                DataReturnedGb = (int)Math.Round(downloaded),
                DataLostGb = (int)Math.Round(lost),
                RemainingDataGb = (int)Math.Round(storageUsed),
                Brownouts = failures,
                CostMillions = Design.CostMillions
            };
            if (result.CompletionPercent < 100) result.Suggestions.Add("Increase useful science returned to Earth; observation alone is not enough.");
            if (result.RemainingDataGb > 0) result.Suggestions.Add("Some data never reached Earth. Consider a faster antenna or better downlink scheduling.");
            if (result.DataLostGb > 0) result.Suggestions.Add("Onboard storage overflowed. Increase capacity or collect less data per pass.");
            if (failures > 0) result.Suggestions.Add("Plan around power-hungry activities; a larger battery may help.");
            if (result.ScienceCollected < TargetScience) result.Suggestions.Add("Choose a payload and orbit better aligned with the scientific objective.");
            if (result.Suggestions.Count == 0) result.Suggestions.Add("Excellent result. Try meeting the objective with a less expensive spacecraft.");
            return result;
        }
    }
}
