# Mission Architect — Unity Starter

A Unity 6-compatible starting point for an interactive **Space Mission Design Game**, inspired by NASA Space Apps Challenge 2026.

This version uses **C# + Unity UI Toolkit (UXML / USS)**. It is a game UI and simulation starter, not an exported executable or a NASA-endorsed simulator.

## Setup (Unity 6)

1. In **Unity Hub**, create a new project with a standard 2D or 3D template. A 2D Core project is sufficient.
2. Copy the supplied **`Assets/MissionArchitect`** folder into your Unity project's **`Assets`** folder, retaining the directory structure. Do not nest an extra `Assets` folder.
3. Wait for Unity to import and compile the scripts.
4. In Unity's top menu, select **Tools > Mission Architect > Create Demo Scene**.
5. In the Project window, open **`Assets/MissionArchitect/Scenes/MissionArchitectDemo.unity`**.
6. Press **Play**. Use a 16:9 Game view at approximately 1280x720 or larger for the intended desktop layout.

The scene generator creates the runtime `UIDocument`, `PanelSettings` asset and a background camera. It saves a new scene without overwriting your current scene. If you run it again after the scene exists, it leaves that scene untouched.

## Files and ownership

| File | Purpose |
|---|---|
| `Scripts/MissionSimulation.cs` | Pure C# spacecraft catalogs, preflight checks, four-turn operations simulation and scoring |
| `Scripts/MissionGameController.cs` | Unity MonoBehaviour controlling the eight stages, choices, live telemetry, and replay |
| `Resources/MissionUI.uxml` | Declarative UI Toolkit layout: sidebar, content viewport and telemetry |
| `Resources/MissionStyle.uss` | Dark mission-control visual styling and responsive flex layouts |
| `Editor/MissionSceneBuilder.cs` | Unity menu item to generate a demo scene |

All paths above are under `Assets/MissionArchitect/`.

## Complete game loop

1. Pick **Wildfire Watch**, **Forest Sentinel**, or **Crop Pulse**.
2. Pick a simplified **orbit preset** that changes mission science efficiency and launcher capacity.
3. Pick the **science payload**: standard camera, high-resolution camera, thermal sensor or multispectral instrument.
4. Configure **solar arrays**, **communication antenna**, **battery reserve**, and **data storage**.
5. Select a **rocket**. Observe how each choice affects cost, mass, power and data downlink.
6. Pass **preflight review**. Overbudget or overweight configurations cannot launch; other limitations can appear as warnings.
7. After launch, play **four orbital windows**. Each turn choose exactly one action:
   - Full observation
   - Efficient observation
   - Downlink science data (only during ground contact)
   - Conserve and recharge
8. Read the **mission report**. Replay with the same spacecraft or return to redesign.

The main teaching principle: **collected data only earns mission progress when it is sent back to Earth**. Expensive components alone cannot guarantee success.

## Gameplay tuning

Edit `MissionCatalog` near the top of `MissionSimulation.cs`:

- `Missions` controls scientific targets.
- `Orbits` controls science multipliers and relative launch difficulty.
- `Payloads` controls science fit, mass, power, cost and data per observation.
- `Solar`, `Antennas`, `Batteries`, `Storages`, `Rockets` control engineering trade-offs.
- `MissionEngine.Windows` controls sunlit/eclipse and ground-contact opportunities.

`MissionSession.Execute(...)` handles the operations and the `Evaluate()` method handles scoring.

## What is included—and what is not

**Included:** Functional interface structure, selectable spacecraft components, engineering rules, an operational decision loop, mission scoring, C# models, an editor scene-creation command.

**Not yet included:** 3D spacecraft editor, orbital physics, saved games, multiplayer, NASA live data, sound, animations and a complete level system. These are good next milestones once the loop is tested with players.

**Model limitation:** All example prices, physical parameters, orbital assumptions, contact windows, science points and scores are invented for game design. They are not real NASA engineering datasets. The 3D scene, Editor import, and build have not been run in this environment because the Unity Editor is not installed here; please verify in your local Unity installation.

## Common setup issues

- **Blank Game view:** Ensure the demo scene is open, the `Mission Architect UI + Game Controller` GameObject has a `UIDocument`, and its Panel Settings and Source Asset fields are populated.
- **UI not styled:** Verify that `MissionStyle.uss` is inside `Assets/MissionArchitect/Resources` so the runtime can load it.
- **Scene menu missing:** Wait for C# compilation to finish and inspect the Console for import errors.
- **Can't see all choices:** Scroll the center panel with the mouse wheel.

## Suggested next development tasks

1. Validate the prototype on your target Unity version and adjust UI font/spacing as needed.
2. Add a 3D satellite preview reflecting payload, panel and antenna selections.
3. Replace illustrative numbers with sourced NASA spacecraft data.
4. Add scenarios, trade-off explanations and structured mission debriefs.
5. Introduce multiplayer roles only after the single-player experience is engaging.
