using System;
using System.IO;
using System.Text.Json;
using OrbitalFrontier.Core;

static void Check(bool condition, string description)
{
    if (!condition) throw new Exception(description);
    Console.WriteLine("PASS   " + description);
}

static void RunUntil(Mission m, Func<FlightConsole, bool> done, double limit = 300)
{
    for (int i = 0; i < limit * 20 && m.Console.running && !done(m.Console); i++) m.Tick(0.05);
    if (!done(m.Console))
        throw new Exception($"Timed out: {m.Console.status}; MET {m.Console.time:0.0}, AGL {m.Console.elements.altitude:0.0}, stage {m.Console.stage}, range {m.Console.scanRange:0.0}");
}

var catalog = JsonSerializer.Deserialize<GameCatalog>(File.ReadAllText(Path.Combine(AppContext.BaseDirectory, "mission.json")),
    new JsonSerializerOptions { IncludeFields = true });
double radius = catalog.moonRadius + 100000;
var orbit = new OrbitState(new VectorD(radius, 0, 0), new VectorD(0, 0, Math.Sqrt(catalog.moonMu / radius)));
var elements = Orbit.Describe(orbit, catalog.moonMu, catalog.moonRadius);
Check(Math.Abs(elements.peri - 100) < 1e-8 && Math.Abs(elements.apo - 100) < 1e-8 && elements.eccentricity < 1e-10, "Circular orbit recovers its radius and eccentricity");
var end = Orbit.Coast(orbit, catalog.moonMu, elements.period);
Check((end.p - orbit.p).Norm < 100 && Math.Abs(end.v.Norm - orbit.v.Norm) < 0.001, "Integrator maintains position and speed to tolerance over one revolution");
Check(Math.Abs(SpacecraftStats.DeltaV(1000, 1000, 300) - 2039.235) < 0.02, "Rocket equation reproduces the expected delta-v");
Check(Orbit.IsOccluded(new VectorD(-radius, 0, 0), new VectorD(1, 0, 0), catalog.moonRadius), "Moon obstructs an Earth or Sun ray on the far side");
Check(!Orbit.IsOccluded(new VectorD(radius, 0, 0), new VectorD(1, 0, 0), catalog.moonRadius), "A near-side Earth or Sun ray is clear");

var design = new CraftDesign();
design.Load(catalog.presets[0], 0);
var original = SpacecraftStats.Calculate(catalog, design);
Check(original.ready && original.cost < catalog.mission.maxCost, "Light preset can deploy");
design.Detach(Slot.Engine);
Check(!SpacecraftStats.Calculate(catalog, design).ready, "Missing engine prevents deployment");
design.Install(catalog.FindPart("eng-s"));
design.Rotate(Slot.Solar);
Check(SpacecraftStats.Calculate(catalog, design).power < original.power, "Changing solar mount angle changes output");
design.Load(catalog.presets[1], 1);
Check(SpacecraftStats.Calculate(catalog, design).ready, "Expedition preset can deploy");
design.Load(catalog.presets[0], 0);

var products = Array.ConvertAll(catalog.sites, s => Survey.Analyze(catalog, s, 2));
Check(products[1].slope90 < products[0].slope90 && products[1].slope90 < products[2].slope90, "The NASA data distinguish lunar mare from rough crater terrain");
var coarse = Survey.Analyze(catalog, catalog.sites[1], 1);
Check(coarse.side == 8 && products[1].side == 24 && products[1].volume > coarse.volume && products[1].cellKm < coarse.cellKm, "Precision scans provide smaller cells and a larger product");

foreach (int choice in new[] { 0, 1 })
{
    design.Load(catalog.presets[choice], choice);
    var m = new Mission(catalog, design, true);
    m.ExecutePlan();
    RunUntil(m, c => c.stage == 1);
    Check(m.Console.fuel < original.fuel || choice == 1, "Finite burn expends propellant");
    Check(Math.Abs(m.Console.elements.peri - 65) < 2 && m.Console.elements.bound, "Finite burn qualifies a bound survey orbit");
    for (int i = 0; i < catalog.sites.Length; i++)
    {
        m.Target(i);
        m.SelectResolution(i == 1 ? 2 : 1);
        m.CoastToAccess();
        RunUntil(m, c => c.scanWindow && !c.waiting);
        if (i == 0)
        {
            m.ToggleSystem(1);
            m.BeginScan();
            Check(!m.Console.scanning, "Lidar off prevents scanning");
            m.ToggleSystem(1);
        }
        m.BeginScan();
        RunUntil(m, c => c.scanned[i] > 0);
        Check(m.Console.products[i].side == (i == 1 ? 24 : 8), "Lidar stores the selected resolution at " + catalog.sites[i].name);
    }
    Check(m.Console.stage == 2, "Three products unlock recommendation and downlink");
    m.Recommend(0);
    m.BeginDownlink();
    Check(!m.Console.transmitting, "Downlink rejects a recommendation with only coarse data");
    m.Recommend(1);
    m.ToggleSystem(2);
    m.BeginDownlink();
    Check(!m.Console.transmitting, "Radio off prevents downlink");
    m.ToggleSystem(2);
    m.BeginDownlink();
    RunUntil(m, c => c.stage == 3);
    Check(m.Console.score >= 75 && m.Console.score <= 100 && m.Console.downlinked > 2, "End-to-end survey earns a report with score and transmitted volume");
}

design.Load(catalog.presets[0], 0);
var impact = new Mission(catalog, design, false);
impact.SetPlan(-67, 3);
impact.ExecutePlan();
RunUntil(impact, c => !c.autoBurn);
impact.SetWarp(4);
RunUntil(impact, c => c.stage == -1);
Check(impact.Console.elements.altitude <= 0, "A bad retrograde burn can result in a lunar impact");

var overBudget = new CraftDesign();
overBudget.Load(catalog.presets[1], 1);
overBudget.Install(catalog.FindPart("bat-l"));
Check(!SpacecraftStats.Calculate(catalog, overBudget).ready, "Installing all high-cost parts exceeds the mission budget");

var session = new GameSession(catalog);
session.Apply(Command.OpenHangar);
session.Apply(Command.Deploy, host: false);
Check(session.View.screen == (int)ScreenMode.Hangar, "Only the host can deploy the shared craft");
session.Apply(Command.Deploy);
session.Apply(Command.Home, host: false);
Check(session.View.screen == (int)ScreenMode.Flight, "A crew client cannot terminate the shared mission");

using (var hostLink = new LanLink())
{
    const int testPort = 47847;
    hostLink.StartHost(testPort);
    if (!hostLink.Hosting) throw new Exception(hostLink.Error);
    var crew = new[] { new LanLink(), new LanLink(), new LanLink(), new LanLink() };
    try
    {
        string remoteCommand = null, remoteState = null;
        void PollNetwork()
        {
            hostLink.Poll(.02, c => remoteCommand = c, _ => {});
            foreach (var client in crew) client.Poll(.02, _ => {}, s => remoteState = s);
            System.Threading.Thread.Sleep(2);
        }
        for (int i = 0; i < 3; i++) crew[i].StartJoin("127.0.0.1", testPort);
        for (int i = 0; i < 140 && (hostLink.CrewCount != 4 || !crew[2].Joined); i++) PollNetwork();
        Check(hostLink.CrewCount == 4 && crew[0].Joined && crew[1].Joined && crew[2].Joined, "TCP host accepts three remote crew members");
        var hostSnapshot = JsonSerializer.Serialize(session.View, new JsonSerializerOptions { IncludeFields = true, IgnoreReadOnlyProperties = true });
        hostLink.Broadcast(hostSnapshot);
        crew[1].SendCommand("{\"command\":20}");
        for (int i = 0; i < 140 && (remoteCommand == null || remoteState == null); i++) PollNetwork();
        Check(remoteCommand == "{\"command\":20}" && remoteState == hostSnapshot && crew[1].CrewCount == 4,
            "A crew command reaches the host and the shared mission snapshot arrives byte for byte across TCP");
        crew[3].StartJoin("127.0.0.1", testPort);
        for (int i = 0; i < 140 && crew[3].Error == null; i++) PollNetwork();
        Check(!crew[3].Joined && hostLink.CrewCount == 4, "A fifth player cannot join the four-person room");
        crew[2].Leave();
        for (int i = 0; i < 140 && hostLink.CrewCount != 3; i++) PollNetwork();
        Check(hostLink.CrewCount == 3, "Disconnect releases a crew slot");
        crew[2].StartJoin("127.0.0.1", testPort);
        for (int i = 0; i < 140 && (hostLink.CrewCount != 4 || !crew[2].Joined); i++) PollNetwork();
        Check(hostLink.CrewCount == 4 && crew[2].Joined, "Disconnected crew member can join again");
    }
    finally
    {
        foreach (var client in crew) client.Dispose();
    }
}
