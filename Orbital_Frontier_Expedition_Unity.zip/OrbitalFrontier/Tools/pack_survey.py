"""Package a .NET WebAssembly publish as one offline, double-clickable HTML file."""
import argparse
import base64
import json
from pathlib import Path


def to_base64(path):
    return base64.b64encode(path.read_bytes()).decode("ascii")


def to_base64_loader(path):
    # A blob URL cannot be a base for sibling URLs. The resource hook below
    # supplies each asset, and the document URL gives the loader a valid base.
    script = path.read_text(encoding="utf-8")
    before = "const t=import.meta.url,o=t.indexOf"
    after = "const t=globalThis.location.href,o=t.indexOf"
    if script.count(before) != 1:
        raise ValueError("The .NET loader changed. Update the offline URL adapter.")
    return base64.b64encode(script.replace(before, after).encode("utf-8")).decode("ascii")


def package(source):
    framework = source / "_framework"
    config = json.loads((framework / "blazor.boot.json").read_text(encoding="utf-8"))
    runtime_modules = {}
    for key in ("jsModuleNative", "jsModuleRuntime"):
        for name in config["resources"][key]:
            module = framework / name
            if key == "jsModuleNative":
                native = module.read_text(encoding="utf-8")
                before = 'new URL("dotnet.native.wasm",import.meta.url).href'
                if before not in native:
                    raise ValueError("The native WebAssembly loader changed.")
                native = native.replace(before, 'new URL("dotnet.native.wasm",globalThis.location.href).href')
                runtime_modules[name] = base64.b64encode(native.encode("utf-8")).decode("ascii")
            else:
                runtime_modules[name] = to_base64(module)
    binary = {}
    for key in ("wasmNative", "assembly"):
        for name in config["resources"][key]:
            binary[name] = to_base64(framework / name)
    images = {path.name: "data:image/jpeg;base64," + to_base64(path)
              for path in (source / "media").glob("*.jpg")}
    stylesheet = (source / "flight.css").read_text(encoding="utf-8")
    for path in (source / "media").glob("*.ttf"):
        stylesheet = stylesheet.replace("media/" + path.name, "data:font/ttf;base64," + to_base64(path))
    stylesheet = stylesheet.replace("media/lunar_albedo.jpg", images["lunar_albedo.jpg"])
    catalog = (source / "media/mission.json").read_text(encoding="utf-8")
    header = (
        "const boot = " + json.dumps(config, separators=(",", ":")) + ";\n"
        "const modules = " + json.dumps(runtime_modules, separators=(",", ":")) + ";\n"
        "const binaries = " + json.dumps(binary, separators=(",", ":")) + ";\n"
        "const media = " + json.dumps(images, separators=(",", ":")) + ";\n"
        "const embeddedCatalog = " + json.dumps(catalog, ensure_ascii=False) + ";\n"
        "function from64(value) { return Uint8Array.from(atob(value), c => c.charCodeAt(0)); }\n"
        "function moduleURL(value) { return URL.createObjectURL(new Blob([from64(value)], { type: 'text/javascript' })); }\n"
        "const locators = Object.fromEntries(Object.entries(modules).map(([key, value]) => [key, moduleURL(value)]));\n"
        "const mRuntime = await import(moduleURL('" + to_base64_loader(framework / "dotnet.js") + "'));\n"
        "const THREE = await import(moduleURL('" + to_base64(source / "three.module.min.js") + "'));\n"
        "const embeddedDotnet = mRuntime.dotnet.withConfig({...boot, cacheBootResources:false}).withResourceLoader((kind, name) => {\n"
        "  if (locators[name]) return locators[name];\n"
        "  if (binaries[name]) return Promise.resolve(new Response(from64(binaries[name]), {headers:{'content-type':'application/wasm'}}));\n"
        "  return undefined;\n"
        "});\n"
    )
    stage = (source / "world.js").read_text(encoding="utf-8")
    stage = stage.replace("import * as THREE from './three.module.min.js';", "").replace("export function", "function")
    stage = stage.replace("'./media/lunar_albedo.jpg'", "media['lunar_albedo.jpg']")
    game = (source / "main.js").read_text(encoding="utf-8")
    game = game.replace("import { dotnet } from './_framework/dotnet.js';", "")
    game = game.replace("import { createWorld } from './world.js';", "")
    # Keep the production script identical except for the two resource loaders.
    game = game.replace("dotnet.withDiagnosticTracing(false).create()", "embeddedDotnet.withDiagnosticTracing(false).create()")
    game = game.replace("fetch('./media/mission.json').then(response=>{if(!response.ok) throw Error('Mission catalog unavailable');return response.text();})", "Promise.resolve(embeddedCatalog)")
    game = game.replace("'./media/'+name+'.jpg'", "media[name+'.jpg']")
    if "fetch('./media" in game:
        raise ValueError("The source resource loader changed. Update the offline packager.")
    style_tag = '<link rel="stylesheet" href="./flight.css">'
    script_tag = '<script type="module" src="./main.js"></script>'
    html = (source / "index.html").read_text(encoding="utf-8")
    html = html.replace(style_tag, f"<style>\n{stylesheet}\n</style>")
    html = html.replace(script_tag, "<script type=\"module\">\n" +
                        (header + stage + game).replace("</script", "<\\/script") + "\n</script>")
    notices = []
    for name in ("three-LICENSE.txt", "dotnet-LICENSE.txt", "dotnet-ThirdPartyNotices.txt",
                 "Barlow-OFL.txt", "IBMPlexMono-OFL.txt"):
        path = source / name
        if path.is_file():
            notices.append(name + "\n" + path.read_text(encoding="utf-8", errors="replace"))
    if notices:
        html = html.replace("</html>", "<!-- Included licenses\n" +
                            "\n\n".join(notices).replace("-->", "-- >") + "\n-->\n</html>")
    return html


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("wwwroot", type=Path)
    parser.add_argument("output", type=Path)
    args = parser.parse_args()
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(package(args.wwwroot), encoding="utf-8")


if __name__ == "__main__":
    main()
