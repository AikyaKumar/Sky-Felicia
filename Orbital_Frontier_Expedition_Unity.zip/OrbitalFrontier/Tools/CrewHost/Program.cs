using System;
using System.Diagnostics;
using System.IO;
using System.Net.WebSockets;
using System.Text.Json;
using System.Threading;
using System.Threading.Channels;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.FileProviders;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;
using OrbitalFrontier.Core;

var appRoot = AppContext.BaseDirectory;
var browserRoot = Path.GetFullPath(Environment.GetEnvironmentVariable("FRONTIER_WEB_ROOT") ?? Path.Combine(appRoot, "wwwroot"));
if (!File.Exists(Path.Combine(browserRoot,"index.html")))
{
    Console.Error.WriteLine("The browser files are missing. Run from the full Crew Host package or set FRONTIER_WEB_ROOT to the browser publish's wwwroot.");
    return;
}
var builder = WebApplication.CreateBuilder(args);
builder.Logging.SetMinimumLevel(LogLevel.Warning);
if (string.IsNullOrEmpty(Environment.GetEnvironmentVariable("ASPNETCORE_URLS")))
    builder.WebHost.UseUrls("http://0.0.0.0:47620");
var app = builder.Build();
var browserFiles = new PhysicalFileProvider(browserRoot);
var library = Path.Combine(browserRoot, "media");
var json = new JsonSerializerOptions { IncludeFields = true, IgnoreReadOnlyProperties = true };
var catalog = JsonSerializer.Deserialize<ExpeditionCatalog>(File.ReadAllText(Path.Combine(library,"expedition.json")),json);
if (catalog == null) throw new InvalidOperationException("Cannot load the expedition catalog.");
var grids = Array.ConvertAll(catalog.worlds, world =>
    new SurfaceGrid(world, File.ReadAllBytes(Path.Combine(library, world.heightFile + ".bytes"))));
var sim = new ExpeditionSession(catalog, grids);
sim.CrewActive(0, false);
var room = new ExpeditionRoom(sim, json);
app.UseWebSockets(new WebSocketOptions { KeepAliveInterval = TimeSpan.FromSeconds(20) });
app.UseDefaultFiles(new DefaultFilesOptions { FileProvider = browserFiles });
app.UseStaticFiles(new StaticFileOptions {
    FileProvider = browserFiles,
    ContentTypeProvider = new Microsoft.AspNetCore.StaticFiles.FileExtensionContentTypeProvider {
        Mappings = { [".bytes"] = "application/octet-stream", [".wasm"] = "application/wasm" }
    }
});
app.MapGet("/crew", async context => {
    if (!context.WebSockets.IsWebSocketRequest)
    {
        context.Response.StatusCode = 400;
        return;
    }
    if (context.Request.Headers.TryGetValue("Origin",out var origin) &&
        Uri.TryCreate(origin.ToString(),UriKind.Absolute,out var address) &&
        !string.Equals(address.Authority,context.Request.Host.Value,StringComparison.OrdinalIgnoreCase))
    {
        context.Response.StatusCode = 403;
        return;
    }
    using var socket = await context.WebSockets.AcceptWebSocketAsync();
    await room.Serve(socket,context.Request.Query["resume"].ToString(),context.RequestAborted);
});
Console.WriteLine("Orbital Frontier Crew Host");
Console.WriteLine("Open http://localhost:47620/ in Chrome or Edge, then choose Crew LAN.");
Console.WriteLine("Other crew use this computer’s local IPv4 address and port 47620. Press Ctrl+C to end the session.");
var loop = room.Run(app.Lifetime.ApplicationStopping);
await app.RunAsync();
await loop;

sealed class ExpeditionRoom
{
    readonly ExpeditionSession session;
    readonly JsonSerializerOptions json;
    readonly object gate = new object();
    readonly Player[] players = new Player[4];

    public ExpeditionRoom(ExpeditionSession session, JsonSerializerOptions json)
    {
        this.session = session;
        this.json = json;
    }

    public async Task Run(CancellationToken token)
    {
        var stopwatch = Stopwatch.StartNew();
        double last = 0, broadcast = 0;
        try
        {
            using var timer = new PeriodicTimer(TimeSpan.FromMilliseconds(40));
            while (await timer.WaitForNextTickAsync(token))
            {
                double now = stopwatch.Elapsed.TotalSeconds;
                lock (gate)
                {
                    if (Array.Exists(players, p => p?.online == true))
                    {
                        session.Tick(Math.Min(now-last,.20));
                        if (now >= broadcast)
                        {
                            broadcast = now + .091;
                            foreach (var player in players)
                            {
                                if (player?.online != true) continue;
                                var frame = JsonSerializer.SerializeToUtf8Bytes(new Frame { seat=player.seat, resume=player.token, view=session.View },json);
                                player.sending.Writer.TryWrite(frame);
                            }
                        }
                    }
                }
                last=now;
            }
        }
        catch (OperationCanceledException) { }
    }

    public async Task Serve(WebSocket client,string resume,CancellationToken token)
    {
        Player player;
        lock(gate)
        {
            int id = string.IsNullOrEmpty(resume) ? -1 :
                Array.FindIndex(players, item => item?.token == resume && !item.online);
            if (id < 0) id = Array.FindIndex(players, item => item == null);
            if (id < 0) id = Array.FindIndex(players, item => item?.online == false);
            player = id < 0 ? null : new Player(id, players[id]?.token == resume ? resume : Guid.NewGuid().ToString("N"));
            if(player != null)
            {
                players[id] = player;
                session.CrewActive(id,true);
                player.sending.Writer.TryWrite(JsonSerializer.SerializeToUtf8Bytes(
                    new Frame { seat=id,resume=player.token,view=session.View },json));
            }
        }
        if(player == null)
        {
            await client.SendAsync(new ReadOnlyMemory<byte>(JsonSerializer.SerializeToUtf8Bytes(new { error="All four crew positions are occupied." })),
                WebSocketMessageType.Text,true,token);
            await client.CloseOutputAsync(WebSocketCloseStatus.PolicyViolation,"Crew room full",token);
            return;
        }

        using var cancel=CancellationTokenSource.CreateLinkedTokenSource(token);
        var writer=Write(client,player,cancel.Token);
        var reader=Read(client,player,cancel.Token);
        try { await Task.WhenAny(writer,reader); }
        finally
        {
            cancel.Cancel();
            try { await Task.WhenAll(writer,reader); }
            catch (Exception e) when (e is OperationCanceledException || e is WebSocketException || e is IOException) { }
            lock(gate)
            {
                player.online=false;
                if (players[player.seat] == player) session.CrewActive(player.seat, false);
            }
        }
    }

    static async Task Write(WebSocket client, Player player, CancellationToken token)
    {
        await foreach(var bytes in player.sending.Reader.ReadAllAsync(token))
            await client.SendAsync(new ReadOnlyMemory<byte>(bytes),WebSocketMessageType.Text,true,token);
    }

    async Task Read(WebSocket client,Player player,CancellationToken token)
    {
        var buffer=new byte[2560];
        int count=0;
        double window=0;
        var clock=Stopwatch.StartNew();
        while(client.State==WebSocketState.Open)
        {
            int length=0;
            ValueWebSocketReceiveResult part;
            do
            {
                if(length>=buffer.Length) return;
                part=await client.ReceiveAsync(buffer.AsMemory(length),token);
                if(part.MessageType!=WebSocketMessageType.Text) return;
                length+=part.Count;
            }while(!part.EndOfMessage);
            double now=clock.Elapsed.TotalSeconds;
            if(now-window>=1) {window=now;count=0;}
            if(++count>40) continue;
            Wire input;
            try { input=JsonSerializer.Deserialize<Wire>(buffer.AsSpan(0,length),json); }
            catch(JsonException) { continue; }
            if(input==null||input.command<1||input.command>(int)ExpeditionCommand.Endurance)continue;
            lock(gate)
            {
                if(players[player.seat]!=player) return;
                session.Apply((ExpeditionCommand)input.command,player.seat,input.n,input.a,input.b,input.c);
            }
        }
    }

    sealed class Player
    {
        public readonly int seat;
        public readonly string token;
        public bool online=true;
        public readonly Channel<byte[]> sending=Channel.CreateBounded<byte[]>(new BoundedChannelOptions(1) {
            SingleReader=true,SingleWriter=false,FullMode=BoundedChannelFullMode.DropOldest
        });
        public Player(int seat,string token){this.seat=seat;this.token=token;}
    }

    sealed class Frame { public int seat; public string resume; public ExpeditionView view; }
    sealed class Wire
    {
        public int command = 0, n = 0;
        public double a = 0, b = 0, c = 0;
    }
}
