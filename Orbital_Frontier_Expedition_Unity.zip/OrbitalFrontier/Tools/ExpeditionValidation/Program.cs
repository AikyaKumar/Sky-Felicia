using System;
using System.IO;
using System.Text.Json;
using OrbitalFrontier.Core;
using X = OrbitalFrontier.Core.ExpeditionCommand;

var dir = Path.Combine(AppContext.BaseDirectory, "Terrain");
var data = JsonSerializer.Deserialize<ExpeditionCatalog>(File.ReadAllText(Path.Combine(dir, "expedition.json")), new JsonSerializerOptions { IncludeFields = true });
var ground = Array.ConvertAll(data.worlds, w => new SurfaceGrid(w, File.ReadAllBytes(Path.Combine(dir, w.heightFile+".bytes"))));
void Check(bool result,string why)
{
    if (!result) throw new InvalidOperationException(why);
    Console.WriteLine("PASS " + why);
}
foreach (int selection in new[]{0,1,2})
{
    const int person=0;
    var sim=new ExpeditionSession(data,ground);
    var state=sim.View;
    void Cmd(X x,int n=0,double a=0,double b=0,double c=0) => sim.Apply(x,person,n,a,b,c);
    string Status() => state.telemetry?.status+"; "+state.crew[person].message;
    void Wait(Func<bool> predicate, double seconds)
    {
        for (double t=0; t<seconds && !predicate() && state.phase != 7; t += .04) sim.Tick(.04);
        if (!predicate()) throw new InvalidOperationException("Timed out. Phase "+state.phase+": "+Status());
    }
    void Walk(double x,double z,double radius=.95)
    {
        for (int i=0;i<2500;i++)
        {
            var me=state.crew[person];
            double dx=x-me.x,dz=z-me.z,l=Math.Sqrt(dx*dx+dz*dz);
            if(l<=radius){Cmd(X.Move);return;}
            Cmd(X.Move,0,dx/l,-dz/l);sim.Tick(.15);
            if(state.phase==7) break;
        }
        throw new Exception("Cannot walk: "+x+","+z+" from "+state.crew[person].x+","+state.crew[person].z+" "+Status());
    }
    void Station(int n)
    {
        Walk(0,state.crew[person].z);
        double z = Math.Max(-7.52,CrewStation.Z[n]);
        Walk(0,z);
        Walk(CrewStation.X[n]*.55,z);
    }
    const int helm=CrewStation.Helm, nav=CrewStation.Nav, engineering=CrewStation.Engineering, science=CrewStation.Science, coms=CrewStation.Comms,hatch=CrewStation.Hatch;
    Cmd(X.Vehicle,selection); Check(state.budget.ready,"Preset "+selection+" valid "+string.Join(" ",state.budget.issues));
    if(selection==1)
    {
        Cmd(X.Launcher,0);Check(!state.budget.ready,"Lunar-only launcher rejected at Mars");
        Cmd(X.Launcher,1);
    }
    Cmd(X.Launch); var t=state.telemetry;
    Check(state.phase==1,"Mission starts at ascent");
    Cmd(X.Inspect,engineering);Check(t.inspectedMask==0,"Remote inspection is rejected");
    Station(helm); Wait(()=>t.staged,12); Cmd(X.Stage); Wait(()=>t.staged,12); Cmd(X.Stage);
    Check(state.phase==2 && t.stageCount==2,"Helm completes two staging events");
    Station(nav); Cmd(X.Coast,1); Wait(()=>t.fault==1,24);
    Station(engineering); int before=t.spares; Cmd(X.Repair,engineering);
    Check(t.fault==1,"Diagnostics precede a hardware replacement");
    Cmd(X.Inspect,engineering);Cmd(X.Repair,engineering);Check(t.fault==0 && t.spares==before-1,"Engineering repair restores the controller and uses a spare");
    Station(nav);Wait(()=>t.progress>=1,35); double fuel=t.fuel;Cmd(X.Capture);Wait(()=>state.phase==3,10);
    Check(t.fuel<fuel && t.orbitalPeri>60,"Capture uses propellant and produces a bound orbit");
    Station(science);Cmd(X.Inspect,science);Check(t.measured>0,"Science station measures the landing corridor");
    Station(helm);Cmd(X.BeginDescent);Check(state.phase==4,"Helm commits to terminal descent");
    Wait(()=>state.phase==5,150);
    Check(t.touchdownV<3.3 && t.touchdownHorizontal<3,"Controlled touchdown at "+data.worlds[state.design.world].name);
    Station(hatch);Cmd(X.Airlock);Check(state.crew[0].outside,"Airlock transitions to first-person EVA");
    double oxygen=state.crew[0].oxygen;
    var world=data.worlds[state.design.world];
    foreach (var point in world.points)
    {
        Walk(point.x,point.z,7);
        Cmd(X.Sample,Array.IndexOf(world.points,point));
    }
    Check(t.samples==2 && t.stored>3 && state.crew[0].oxygen<oxygen,"Two physical waypoints yield data and consume suit oxygen");
    Walk(t.x,t.z+9.8,4);Cmd(X.Airlock);Check(!state.crew[0].outside,"Crew return via the physical hatch");
    Station(coms);Cmd(X.Downlink);Wait(()=>state.phase==6,150);
    Check(t.reportScore>=60 && t.delivered>3, "Downlinked mission scored "+t.reportScore+"/100");
}

void FullScenario(int target, int objective, bool manualFailure = false)
{
    var x = new ExpeditionSession(data, ground);
    var v = x.View;
    void Act(X cmd,int n=0,double a=0,double b=0) => x.Apply(cmd,0,n,a,b);
    void Advance(double seconds) { for(double time=0;time<seconds;time+=.04)x.Tick(.04); }
    void Walk(double a,double z)
    {
        for(int i=0;i<2500;i++)
        {
            var u=v.crew[0];double dx=a-u.x,dz=z-u.z,m=Math.Sqrt(dx*dx+dz*dz);
            if(m<.90){Act(X.Move);return;}
            Act(X.Move,0,dx/m,-dz/m); Advance(.10);
        }
        throw new Exception("Scenario movement stopped at "+v.crew[0].x+","+v.crew[0].z);
    }
    void Station(int n)
    {
        Walk(0,v.crew[0].z); double z=Math.Max(-7.49,CrewStation.Z[n]);
        Walk(0,z); Walk(CrewStation.X[n]*.56,z);
    }
    Act(X.World,target);
    Act(X.Objective,objective);
    if(manualFailure)Act(X.Difficulty,1);
    Act(X.Launch);Station(0);Advance(10);Act(X.Stage);Advance(8.5);Act(X.Stage);
    Station(1);Act(X.Coast,1);Advance(24);
    Station(2);Act(X.Inspect,2);Act(X.Repair,2);Station(1);Act(X.Capture);Advance(5.9);
    Station(4);Act(X.Inspect,4);
    if(objective==1)
    {
        Advance(5.5);
        for(int i=0;i<5&&v.telemetry.orbitalPasses<2;i++) {Act(X.Inspect,4);Advance(6);}
        Check(v.telemetry.orbitalPasses==2,"Orbital survey acquired two products");
        Station(5);
        for(int i=0;i<12&&v.phase<6;i++) {Act(X.Downlink);Advance(13);}
        Check(v.phase==6,"Orbital survey downlink completes from orbit");
        return;
    }
    Station(0);Act(X.BeginDescent);
    if(manualFailure)
    {
        Advance(55);
        Check(v.phase==7&&v.telemetry.summary.Contains("Hard landing"), "Expert descent without thrust ends in a measured hard landing");
        return;
    }
    for(int i=0;i<2200&&v.phase==4;i++) Advance(.04);
    Check(v.phase==5,"Recovery mission touched down");
    Station(3);
    for(int i=0;i<500&&v.telemetry.fault==0;i++) Advance(.04);
    Advance(8);
    Check(v.telemetry.fault==2 && v.telemetry.pressure<100,"Recovery pressure seal leaks and reduces cabin pressure");
    Act(X.Inspect,3);Act(X.Repair,3);Advance(24);
    Check(v.telemetry.fault==0&&v.telemetry.pressure>80,"Life-support repair restored pressure and consumed the second spare");
    Station(6);Act(X.Airlock);
    var t=v.telemetry;
    Walk(t.roverX,t.roverZ);Act(X.SetRover);
    double parking=t.roverZ;
    Walk(t.roverX,t.roverZ-17);Act(X.SetRover);
    Check(!v.crew[0].rover && t.roverId<0 && t.roverZ<parking-12,"Rover remains parked after dismount");
    var poi=data.worlds[target].points[0];Walk(poi.x,poi.z);Act(X.Sample,0);
    Walk(t.x,t.z+9.8);Act(X.Airlock);Station(5);Act(X.Downlink);Advance(26);
    Check(v.phase==6,"Recovery mission ends with repaired pressure and field record");
}
FullScenario(0,1);
FullScenario(0,2);
FullScenario(1,0,true);

var bridge = new ExpeditionSession(data, ground);
bridge.CrewActive(1,true);
bridge.Apply(X.World,1,1);
Check(bridge.View.design.world==1,"Crew member can edit the shared mission design");
bridge.Apply(X.Launch,1);
Check(bridge.View.phase==0,"A remote crew member cannot launch the vehicle");
bridge.Apply(X.Launch,0);
var hostStart=bridge.View.crew[0].z;
var guestStart=bridge.View.crew[1].z;
bridge.Apply(X.Move,1,0,0,-1,0);
bridge.Tick(.22);
Check(bridge.View.crew[0].z==hostStart&&bridge.View.crew[1].z>guestStart,
      "Remote motion changes only that authenticated crew member");
bridge.CrewActive(1,false);
Check(!bridge.View.crew[1].active,"Disconnection releases the active crew position");
