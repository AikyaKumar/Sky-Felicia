"""Package a .NET WebAssembly expedition build as an offline HTML game."""
import argparse
import json
from pathlib import Path
from pack_survey import to_base64, to_base64_loader


def package(source):
    framework = source / "_framework"
    config = json.loads((framework / "blazor.boot.json").read_text(encoding="utf-8"))
    import base64

    modules = {}
    for key in ("jsModuleNative", "jsModuleRuntime"):
        for name in config["resources"][key]:
            module = framework / name
            if key == "jsModuleNative":
                native = module.read_text(encoding="utf-8")
                before = 'new URL("dotnet.native.wasm",import.meta.url).href'
                if before not in native:
                    raise ValueError("The native WebAssembly loader changed.")
                native = native.replace(before, 'new URL("dotnet.native.wasm",globalThis.location.href).href')
                modules[name] = base64.b64encode(native.encode("utf-8")).decode("ascii")
            else:
                modules[name] = to_base64(module)
    binary = {}
    for key in ("wasmNative", "assembly"):
        for name in config["resources"][key]:
            binary[name] = to_base64(framework / name)

    media = source / "media"
    images = {path.name: "data:image/jpeg;base64," + to_base64(path) for path in media.glob("*.jpg")}
    heights = {path.name: to_base64(path) for path in media.glob("*_height.bytes")}
    sheets = []
    for name in ("flight.css", "expedition.css"):
        style = (source / name).read_text(encoding="utf-8")
        for path in media.glob("*.ttf"):
            style = style.replace("media/" + path.name, "data:font/ttf;base64," + to_base64(path))
        style = style.replace("media/lunar_albedo.jpg", images["lunar_albedo.jpg"])
        sheets.append(style)
    header = (
        "const boot = " + json.dumps(config, separators=(",", ":")) + ";\n"
        "const modules = " + json.dumps(modules, separators=(",", ":")) + ";\n"
        "const binaries = " + json.dumps(binary, separators=(",", ":")) + ";\n"
        "const embeddedImages = " + json.dumps(images, separators=(",", ":")) + ";\n"
        "const embeddedHeight = " + json.dumps(heights, separators=(",", ":")) + ";\n"
        "const embeddedCatalog = " + json.dumps((media / "expedition.json").read_text(encoding="utf-8"), ensure_ascii=False) + ";\n"
        "function from64(value) { return Uint8Array.from(atob(value), c => c.charCodeAt(0)); }\n"
        "function moduleURL(value) { return URL.createObjectURL(new Blob([from64(value)],{type:'text/javascript'})); }\n"
        "const locators = Object.fromEntries(Object.entries(modules).map(([key,value])=>[key,moduleURL(value)]));\n"
        "const mRuntime = await import(moduleURL('" + to_base64_loader(framework / "dotnet.js") + "'));\n"
        "const THREE = await import(moduleURL('" + to_base64(source / "three.module.min.js") + "'));\n"
        "const dotnet = mRuntime.dotnet.withConfig({...boot, cacheBootResources:false}).withResourceLoader((kind,name)=>{\n"
        "  if (locators[name]) return locators[name];\n"
        "  if (binaries[name]) return Promise.resolve(new Response(from64(binaries[name]),{headers:{'content-type':'application/wasm'}}));\n"
        "  return undefined;\n"
        "});\n"
    )
    code = []
    for path in ("expedition-world.js", "expedition-map.js", "expedition.js"):
        js = (source / path).read_text(encoding="utf-8")
        js = "\n".join(l for l in js.splitlines() if not l.startswith("import "))
        js = js.replace("export function", "function")
        if path == "expedition.js":
            start, end = js.index("const file=name"), js.index("const commands=")
            js = js[:start] + ("const file=name=>embeddedImages[name];\n"
                "const jsonAsset=()=>Promise.resolve(embeddedCatalog);\n"
                "const binaryAsset=name=>Promise.resolve(embeddedHeight[name]);\n") + js[end:]
        code.append(js)
    page = (source / "index.html").read_text(encoding="utf-8")
    page = page.replace('<link rel="stylesheet" href="./flight.css">', "<style>\n" + "\n".join(sheets) + "\n</style>")
    page = page.replace('<link rel="stylesheet" href="./expedition.css">', "")
    page = page.replace('<script type="module" src="./expedition.js"></script>',
                        '<script type="module">\n' + (header + "\n".join(code)).replace("</script", "<\\/script") + "\n</script>")
    credits = []
    for name in ("three-LICENSE.txt", "dotnet-LICENSE.txt", "dotnet-ThirdPartyNotices.txt", "Barlow-OFL.txt", "IBMPlexMono-OFL.txt"):
        path = source / name
        if path.exists():
            credits.append(name + "\n" + path.read_text(encoding="utf-8", errors="replace"))
    if credits:
        page = page.replace("</html>", "<!-- Included licenses\n" + "\n\n".join(credits).replace("-->", "-- >") + "\n-->\n</html>")
    return page


if __name__ == "__main__":
    cli = argparse.ArgumentParser(description=__doc__)
    cli.add_argument("wwwroot", type=Path)
    cli.add_argument("output", type=Path)
    args = cli.parse_args()
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(package(args.wwwroot), encoding="utf-8")
